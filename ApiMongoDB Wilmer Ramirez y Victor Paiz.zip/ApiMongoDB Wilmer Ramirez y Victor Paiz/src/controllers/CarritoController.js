const Carrito = require("../models/Carrito");
const CarCtrl = {};

CarCtrl.RenderFormcarrito = (req,res) => {
    res.render('Carrito/NewCarrito');
};

//# Region Crear nuevo carrito

CarCtrl.CreateCarritoForm = async (req,res) => {
    const {Descripcion,FechaRegistro } = req.body;
    const NewCarrito = new Carrito({Descripcion,FechaRegistro});
    await NewCarrito.save();

    console.log(NewCarrito);
    res.render('Carrito');

}

//# region Obtener Registro Del Carrito

CarCtrl.renderCarritoView = async (req,res) => {
    const Car = await Carrito.find();
    res.render('Carrito/ViewAllCarrito',{ Car});
};

CarCtrl.CreateCarritoForm = async(req,res) => {
    const {Descripcion,FechaRegistro} =req.body;
    const NewCarrito = new Carrito({Descripcion, FechaRegistro});
    await NewCarrito.save();

    console.log(NewCarrito);
    res.render('Carrito');



}

//# region Obtener Solo un Carrito

CarCtrl.renderCarritoOne =( req, res) =>{
    const{Nombre} = req.param;
    Carrito.findOne({Descripcion: Nombre}).select({pasword: 0, _id: 0 })
    .then((data) => {
        res.json(data);
    })
    .catch((Error) => res.send(error));
}

CarCtrl.renderCarritoUpdate =async ( req,res) => {

    const{ Nombre} = req.params;
    const NewCar = req.body.Descripcion;
    const Activo = req.body.Activo;

    Carrito.updateOne({Descripcion: Nombre},
        {
            $set: {
                Descripcion: NewCar,
                Activo: Activo
            }
        })
        .then((data) => { res.json(data)})
        .catch((error)=> res.send(error));

}

CarCtrl.renderCarritoDelete = (req,res) => {
    const{Nombre} = req.params;

    Carrito.deleteOne({Descripcion: Nombre})
    .then((data) => res.json(data))
    .catch((error)=> res.send(error));
}
module.exports = CarCtrl;