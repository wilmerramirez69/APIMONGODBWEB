const Producto = require("../models/Producto");
const ProductoCtrl = {};

ProductoCtrl.RenderFormProducto = (req,res) => {
    res.render('Producto/NewProducto');
};

//#region Crear nuevo producto
ProductoCtrl.CreateProductoForm = async (req,res) => {
    const {NombreProducto,Descripcion,Precio,FechaRegistro} = req.body;
    const NewProd = new Producto({NombreProducto,Descripcion,Precio,FechaRegistro});
    await NewProd.save();

    console.log(NewProd);
    res.render('Producto');
    // const NewProd = Producto(req.body);

    // Newprod.save()
    // .then((data) => {
    //     console.log(data);
    //     res.json(data);
    // }).catch((error)=>{
    //     console.error(error);
    //     res.json(error);
    // })
}
//#endregion

//#region Obtener los registros
ProductoCtrl.renderProductoView =  async (req,res) => {
    const Produc = await Producto.find();
    res.render('Producto/ViewAllProducto', { Produc });
   
};
//#endregion

//#region Obtener solo una Producto o un solo registro especifico
ProductoCtrl.renderProductoOne =  (req, res) => {
    const { NombreProducto } = req.params;
    Producto.findOne({ NombreProducto: NombreProducto })
        .then((data) => {
            res.json(data);
        })
        .catch((error) => res.send(error));
}
//#endregion

//#region Actualizar una Producto
ProductoCtrl.renderProductoUpdate = async (req, res) => {
    const { NombreProducto } = req.params;
    const NewDescrip = req.body.Descripcion;
    const Activo = req.body.Activo;

    Producto.updateOne({ Descripcion: NombreProducto },
        {
            $set: {
                Descripcion: NewDescrip,
                Activo: Activo
            }
        })
        .then((data) => { res.json(data) })
        .catch((error) => res.send(error));
}
//#endregion

//#region Eliminar un registro por nombre
ProductoCtrl.renderProductoDelete = (req, res) => {
    const { NombreProducto } = req.params;

    Producto.deleteOne({ Descripcion: NombreProducto })
        .then((data) => res.json(data))
        .catch((error) => res.send(error));
}
//#endregion

module.exports = ProductoCtrl;