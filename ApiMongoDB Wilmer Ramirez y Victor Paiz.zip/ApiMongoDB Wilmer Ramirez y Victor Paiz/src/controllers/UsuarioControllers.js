const Usuario = require("../models/Usuarios");
const pass = require("../Recursos/encriptacion");
const UsuarioCtrl = {};


//#region validar inicio de sesion
UsuarioCtrl.LoginUserForm = async(req, res) => {

    const UsuarioLogin =req.body;
    const UsuarioBD = await Usuario.findOne({
        nombre:UsuarioLogin.nombre})

        if(Usuario != null)
        {
            let Validar =  await pass.CompararPassword(UsuarioLogin.pasword, UsuarioBD.pasword);
            if (Validar)
                res.send("Login Exitoso");
            else
            res.send("Usuario no valido");
        }
        else{
            res.send("Usuario no valido");
        }
}
//#endregion

//#region Crear nuevo usuario
UsuarioCtrl.CreateNewUser = async (req,res)=>{
    console.log(req.body);
    const {Nombre,Apellido,Pasword,Correo} = req.body;
    const NewUser = new Usuario({Nombre,Apellido,Pasword,Correo})
    
    res.send(NewUser);
    // const NewUser = Usuario(req.body);
    // NewUser.pasword = await pass.encryptar(NewUser.pasword); //Encrytar password
 
    // NewUser.save()
    // .then((data)=>{
    //     console.log(data);
    //     res.json(data);
    // })
    // .catch((error)=>{
    //     console.error(error);
    //     res.json(error);
    // })
}
//#endregion

//#region Ver todos los usuarios
UsuarioCtrl.RenderViewAllUsers = async (req, res) => {
    const Users = await Usuario.find();
    //res.render('ViewsUsuarios/ViewsAllUsers', {Users});
    Usuario.find().select({ pasword: 0,__v: 0, _id: 0 })
        .then((data) => {
            res.json(data)
        })
        .catch((error) => res.send(error));
}
//#endregion

//#region Ver informacion solo de un registro
UsuarioCtrl.RenderViewsUserOne = (req, res) => {
    const { nombre } = req.params;
    Usuario.find({ nombre: nombre }).select({ pasword: 0, __v: 0, _id: 0 })
        .then((data) => {
            res.json(data);
        })
        .catch((error) => res.send(error));
}
//#endregion

//#region Actualizar la informacion de un registro
UsuarioCtrl.UpdateInfoUsers = async (req, res) => {
    const { nombre } = req.params;
    const NewNameUser = req.body.nombre;
    const NewEmail = req.body.correo;

    Usuario.updateOne({ nombre: nombre },
        { $set: { nombre: NewNameUser, correo: NewEmail } })
        .then((data) => { res.json(data) })
        .catch((error) => res.send(error));
}
//#endregion

//#region Eliminar un registro de usuario
UsuarioCtrl.DeleteRegisterUser = (req, res) => {
    const { nombre } = req.params;

    Usuario.deleteOne({ nombre: nombre })
        .then((data) => res.json(data))
        .catch((error) => res.send(error));
}
//#endregion

module.exports = UsuarioCtrl;