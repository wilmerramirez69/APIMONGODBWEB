const Marca = require("../models/Marca");
const MarcaCtrl ={};

MarcaCtrl.RenderFormMarca =(req,res) => {
    res.Render('Marca/NewMarca');
};

MarcaCtrl.CreateMarcaForm = async(req,res) =>{
    const {NombreMarca,Descripcion,FechaRegistro } = req.body;
    const NewMar = new Marca({NombreMarca,Descripcion,FechaRegistro});
    await NewMar.save();

    console.log(NewMar);
    res.render('Marca');
}

MarcaCtrl.renderMarcaView = async (req,res) => {
    const Mar = await Marca.find();
    res.render('Marca/ViewAllMarca', { Mar });
};

MarcaCtrl.renderMarcaOne = (req,res) => {
    const { NombreMarca } = req.params;
    Marca.findOne({NombreMarca: NombreMarca})
    .then((data) => {
        res.json(data);
    })
    .catch((error) => res.send(error));
}

MarcaCtrl.renderMarcaUpdate = async (req,res) => {
    const{ NombreMarca } = req.params;
    const NewMarc =req.body.NombreMarca;
    const Activo = req.body.Activo;

    Marca.updateOne({NombreMarca: NombreMarca},
     {
        $set: {
            NombreMarca: NewMarc,
            Activo: Activo
        }
     })

     .then((data)=>{ res.json(data)})
     .catch((error)=> res.send(error));
}

MarcaCtrl.renderMarcadelete = (req,res)=>{
    const { NombreMarca } = req.params;

    Marca.deleteOne({NombreMarca: NombreMarca})
    .then((data)=> res.json(data))
    .catch((error)=> res.send(error));
}
 module.exports= MarcaCtrl;