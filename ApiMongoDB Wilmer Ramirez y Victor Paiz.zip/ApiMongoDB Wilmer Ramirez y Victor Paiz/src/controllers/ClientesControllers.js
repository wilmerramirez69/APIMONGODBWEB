const pass = require("../Recursos/encriptacion");
const Cliente = require("../models/Cliente");
const ClienteCtrl =  {};

//#region validar inicio de sesion
ClienteCtrl.LoginClientForm = async(req,res) => {
    const ClientLogin = req.body;
    const ClientBD = await Cliente.findOne({
        Nombre:ClientLogin.Nombre})

        if (Cliente != null){
        let Validar= await pass.CompararPassword(ClientLogin.Pasword, ClientBD.Pasword);

        if (Validar)
        res.send("Login Exitoso");
        else
        res.send("Credenciales Invalidas");
    }
    else {
        res.send("Credenciales Invalidas");
    }
}
//#endregion

//#region Crear nueuvo usuario
ClienteCtrl.CreateNewUserClient = async (req,res)=>{ 
    const NewCliente = Cliente(req.body);
   NewCliente.Pasword = await pass.encriptar(NewCliente.Pasword);
   
   NewCliente.save()
   .then((data)=>{
       console.log(data);
       res.json(data);
   })
   .catch((error)=>{
       console.error(error);
       res.json(error);
   })
}
//#endregion

//#region Ver todos los usuarios
ClienteCtrl.RenderViewAllCients = (req, res) => {
    Cliente.find().select({ Pasword: 0, __v: 0, _id: 0 })
        .then((data) => {
            res.json(data)
        })
        .catch((error) => res.send(error));
}
//#endregion

//#region Ver informacion solo de un registro
ClienteCtrl.RenderViewClientOne = (req, res) => {
    const { Nombre } = req.params;
    Cliente.findOne({ Nombre: Nombre }).select({ Pasword: 0, _id: 0 })
        .then((data) => {
            res.json(data);
        })
        .catch((error) => res.send(error));
}
//#endregion

//#region Actualizar la informacion de un usuario
ClienteCtrl.UpdateInfoClient = async (req, res) => {
    const { Nombre } = req.params;
    const NewNameClient = req.body.Nombre;
    const NewApellClient = req.body.Apellido;
    const NewEmailClient = req.body.Correo;

    Cliente.updateOne({ Nombre: Nombre },
        {
            $set: {
                Nombre: NewNameClient,
                Apellido: NewApellClient,
                Correo: NewEmailClient
            }
        })
        .then((data) => { res.json(data) })
        .catch((error) => res.send(error));
}
//#endregion

//#region Eliminar un registro de usuario
ClienteCtrl.DeleteRegisterUser = (req, res) => {
    const { Nombre } = req.params;

    Cliente.deleteOne({ Nombre: Nombre })
        .then((data) => res.json(data))
        .catch((error) => res.send(error));
}
//#endregion

module.exports = ClienteCtrl;