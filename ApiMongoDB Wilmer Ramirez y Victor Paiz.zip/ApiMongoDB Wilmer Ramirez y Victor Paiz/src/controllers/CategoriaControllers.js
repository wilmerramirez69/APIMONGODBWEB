const Categoria = require("../models/Categorias");
const CategCtrl = {};
//renderizacion a la pagina para crear nueva categoria
CategCtrl.RenderFormCategoria = (req,res) => {
    res.render('Categoria/NewCategoria');
};

//#region Crear nueva categoria
CategCtrl.CreateCategoriaForm = async (req,res) => {
    const {Descripcion,FechaRegistro} = req.body;
    const NewCate = new Categoria({Descripcion, FechaRegistro});
    await NewCate.save();

    console.log(NewCate);
    res.render('Categoria');
    // const NewCat = Categoria(req.body);

    // NewCat.save()
    // .then((data) => {
    //     console.log(data);
    //     res.json(data);
    // }).catch((error)=>{
    //     console.error(error);
    //     res.json(error);
    // })
}
//#endregion

//#region Obtener los registros
CategCtrl.renderCategoriaView =  async (req,res) => {
   // const Categ = await Categoria.find();
    //res.render('Categorias/ViewAllCategorias', { Categ });
    Categoria.find().select({_id: 0 })
    .then((data) => {
        res.json(data);
    })
    .catch((error) => res.send(error));
};
//#endregion

//#region Obtener solo una categoria o un soolo registro especifico
CategCtrl.renderCategoriaOne =  (req, res) => {
    const { Nombre } = req.params;
    Categoria.findOne({ Descripcion: Nombre }).select({_id: 0 })
        .then((data) => {
            res.json(data);
        })
        .catch((error) => res.send(error));
}
//#endregion

//#region Actualizar una categoria
CategCtrl.renderCategoriaUpdate = async (req, res) => {
    const { Nombre } = req.params;
    const NewDescrip = req.body.Descripcion;
    const Activo = req.body.Activo;

    Categoria.updateOne({ Descripcion: Nombre },
        {
            $set: {
                Descripcion: NewDescrip,
                Activo: Activo
            }
        })
        .then((data) => { res.json(data) })
        .catch((error) => res.send(error));
}
//#endregion

//#region Eliminar un registro por nombre
CategCtrl.renderCategoriaDelete = (req, res) => {
    const { Nombre } = req.params;

    Categoria.deleteOne({ Descripcion: Nombre })
        .then((data) => res.json(data))
        .catch((error) => res.send(error));
}
//#endregion

module.exports = CategCtrl;