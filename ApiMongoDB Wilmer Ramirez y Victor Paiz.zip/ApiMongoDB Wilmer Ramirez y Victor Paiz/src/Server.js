const express = require ("express");
const path = require ("path");
const exphbs = require ('express-handlebars');
const Handlebars = require('handlebars'); // metodo de visualizacion en el navegador
const morgan = require('morgan'); //se indentifica a que puerto o enlace se est accediendo
//const { allowInsecurePrototypeAccess } = require('@handlebars/allow-prototype-access');

//inicializacion
const app = express();

//#region Configuracion
app.set('port', process.env.PORT || 4040);
app.set('views', path.join(__dirname, 'views'));
app.engine('.hbs', exphbs.engine({
    //defaultLayout: 'main',
    //handlebars: allowInsecurePrototypeAccess(Handlebars),
    layoutsdir: path.join(app.get('views'), 'layouts'),
    partialsdir: path.join(app.get('views'), 'partials'),
    extname:'.hbs'
}))
app.set('view engine', 'handlebars'); //metodo para que se pueda visualizar la informacion
app.set('view engine', '.hbs');
//#endregion

//middlewares
app.use(morgan('dev'));
app.use(express.urlencoded({extended: false}));

//#region Llamado de las clases creadas en la carpeta routes
app.use(require('./routers/indexRouters'));
app.use(require('./routers/categoria'));
app.use(require('./routers/clientes'));
app.use(require('./routers/usuario'));
app.use(require('./routers/producto'));



//#endregion

//static files
app.use(express.static(path.join(__dirname, 'public')));

module.exports = app;