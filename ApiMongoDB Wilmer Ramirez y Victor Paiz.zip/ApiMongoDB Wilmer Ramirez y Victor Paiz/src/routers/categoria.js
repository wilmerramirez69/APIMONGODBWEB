const { Router} = require('express');
const express = require ('express');
const router = express.Router();

//#region Llamado de las funciones creadas en la carpeta controllers en la clase de categoriasControllers
const { 
    RenderFormCategoria,
    renderCategoriaView, // ver todas las categorias 
    CreateCategoriaForm, // agregar nueva categoria
    renderCategoriaOne, // ver una sola categoria
    renderCategoriaDelete, // actualizar registro
    renderCategoriaUpdate // eliminar un registro
} = require('../controllers/CategoriaControllers');
//#endregion

router.get('/categoria/add', RenderFormCategoria);

router.post('/categoria/registrar', CreateCategoriaForm);

router.get('/categoria', renderCategoriaView);

router.get('/categoria/:Nombre', renderCategoriaOne);

router.put('/categoria/editar/:Nombre',renderCategoriaUpdate);

router.delete('/categoria/eliminar/:Nombre', renderCategoriaDelete);

module.exports = router;