const { Router} = require('express');
const express = require ('express');
const Producto = require('../models/Producto');
const router = express.Router();

//Metodo para obtener el listado de Producto
router.get("/producto",(req,res)=>{
    Producto.find().select({password:0,__v:0,_id:0})
    .then((data)=>{
        res.json(data)
    })
    .catch((error)=>res.send(error));
})

router.get("/producto/:nombreProducto",(req,res)=>{
    const { nombreProducto }=req.params;

    Producto.find({nombreProducto:nombreProducto}).select({password:0,__v:0,_id:0})
    .then((data)=>{
        res.json(data);
    })
    .catch((error)=>res.send(error));
})

router.put("/producto/:nombreProducto",async (req,res)=>{
    const { nombreProducto }=req.params;
    nuevoProducto = req.body;

    

    if(nombreProducto.Descripcion==undefined){

        console.log('Sin Descripcion');
        Producto.updateOne({nombreProducto:nombreProducto},
            {$set: {
                nombreProducto:nuevoProducto.nombreProducto,
                Descripcion:nuevoProducto.Descripcion,
                precio:nuevoProducto.precio
            }})
            .then((data)=>{res.json(data)})
            .catch((error)=>res.send(error));
    }
    else{
        console.log('Con Descripcion',nuevoProducto.Descripcion);


        Producto.updateOne({nombreProducto:nombreProducto},
            {$set: {
                nombreProducto:nuevoProducto.nombreProducto,
                Descripcion:nuevoProducto.Descripcion,
                precio:nuevoProducto.precio
            }})
        .then((data)=>{res.json(data)})
        .catch((error)=>res.send(error));
    }

   
})

router.delete("/producto/:nombreProducto",(req,res)=>{
    const { nombreProducto }=req.params;

    Producto.deleteOne({nombreProducto:nombreProducto})
    .then((data)=>res.json(data))
    .catch((error)=>res.send(error));
})

module.exports = router;