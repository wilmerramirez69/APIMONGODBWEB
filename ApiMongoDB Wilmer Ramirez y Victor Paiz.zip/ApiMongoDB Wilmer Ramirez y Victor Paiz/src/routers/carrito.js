const { Router} = require('express');
const express = require('express');
const router = express.Router();

const{
    RenderFormcarrito,
    renderCarritoView,
    CreateCarritoForm,
    renderCarritoOne,
    renderCarritoUpdate,
    renderCarritoDelete
} = require('../controllers/CarritoController');

router.get('/carrito/add', RenderFormcarrito);

router.post('/carrito/registrar', CreateCarritoForm);

router.get('/carrito', renderCarritoView);

router.get('/carrito/:Nombre',renderCarritoOne);

router.put('/carrito/editar/:Nombre',renderCarritoUpdate);

router.delete('/carrito/eliminar/:Nombre',renderCarritoDelete);

module.exports = router;