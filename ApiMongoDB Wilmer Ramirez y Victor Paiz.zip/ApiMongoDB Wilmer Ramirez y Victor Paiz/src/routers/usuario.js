const { Router } = require('express');
const express = require('express');
const router = express.Router();

//#region Llamado de las funciones creadas en la carpeta controllers clase de UsuariosControllers
const { 
    CreateNewUser,
    LoginUserForm,
    RenderViewAllUsers,
    RenderViewsUserOne,
    UpdateInfoUsers,
    DeleteRegisterUser
} = require('../controllers/UsuarioControllers');
//#endregion

//Metodo para validar si el usuario se encuentra en sistema y tambien que la informacion que ingrese sea la correcta
router.post('/usuario/login', LoginUserForm)

// Para ingresar un nuevo usuario
router.post('/usuario/registrar', CreateNewUser)

//Mostrar los usuarios que se encuentran registrados
router.get('/usuario/views', RenderViewAllUsers)

//Mostrar la  informacion de un solo usuario
router.get('/usuario/views/:nombre', RenderViewsUserOne)

//Actualizacion de un usuario
router.put('/usuario/update/:nombre', UpdateInfoUsers)

//Eliminar un registro
router.delete('/usuario/delete/:nombre', DeleteRegisterUser)

module.exports = router;