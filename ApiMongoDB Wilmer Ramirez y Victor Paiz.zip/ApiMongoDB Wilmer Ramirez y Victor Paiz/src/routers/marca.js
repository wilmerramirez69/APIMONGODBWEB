const { Router } = require ('express');
const express = require ('express');
const router = express.Router();

const{
    RenderFormMarca,
    CreateMarcaForm,
    renderMarcaView,
    renderMarcaOne,
    renderMarcaUpdate,
    renderMarcadelete
} = require('../controllers/MarcaControllers');
const { renderProductoOne } = require('../controllers/ProductoControllers');

router.get('/marca/add',RenderFormMarca);

router.post('/marca/registrar',CreateMarcaForm);

router.get('/marca/views',renderMarcaView);

router.get('/marca/:NombreMarca', renderProductoOne);

router.put('/marca/editar/:NombreMarca',renderMarcaUpdate);

router.delete('/marca/eliminar/:NombreMarca',renderMarcadelete);

module.exports = router;


