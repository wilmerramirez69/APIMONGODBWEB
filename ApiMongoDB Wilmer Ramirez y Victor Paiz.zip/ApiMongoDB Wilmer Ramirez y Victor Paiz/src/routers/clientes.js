const { Router } = require("express");
const express = require("express");
const Cliente=require("../models/Cliente");

const router = express.Router();

//Metodo para obtener el listado de clientes
router.get("/cliente",(req,res)=>{
    Cliente.find().select({password:0,__v:0,_id:0})
    .then((data)=>{
        res.json(data)
    })
    .catch((error)=>res.send(error));
})

router.get("/cliente/:nombreCliente",(req,res)=>{
    const { nombreCliente }=req.params;

    Cliente.find({nombreCliente:nombreCliente}).select({password:0,__v:0,_id:0})
    .then((data)=>{
        res.json(data);
    })
    .catch((error)=>res.send(error));
})


function validarComplejidadPassword(password){
    let contieneNumero=false;
    let longitudCorrecto=false;
    let contieneMayuscula=false;
    let contieneMinuscula=false;

    if (password.length>=6)
        longitudCorrecto=true;
    
    for(let i=0;i<password.length;i++){
        if (password[i] >= '0' && password[i]<='9')
            contieneNumero=true;
        
        if (password[i] >= 'a' && password[i]<='z')
            contieneMinuscula=true;
        
        if (password[i] >= 'A' && password[i]<='Z')
            contieneMayuscula=true;        
    }

    if (contieneNumero && contieneMayuscula && contieneMinuscula && longitudCorrecto)
        return true;
    else
        return false;

    //.charAt(1)
}

router.post("/cliente",(req,res)=>{
 
    const nuevoCliente = Cliente(req.body);

    if (validarComplejidadPassword(nuevoCliente.password)){
        nuevoCliente.save()
        .then((data)=>{
            console.log(data);
            res.json(data);
        })
        .catch((error)=>{
            console.error(error);
            res.json(error);
        })
    }
    else{
        res.status(500).json({message:"Password con cumple requisitos"});
    }

       
});

router.put("/cliente/:nombreCliente",async (req,res)=>{
    const { nombreCliente }=req.params;
    nuevoCliente = req.body;

    

    if(nombreCliente.password==undefined){

        console.log('Sin password');
        Cliente.updateOne({nombreCliente:nombreCliente},
            {$set: {
                nombreCliente:nuevoCliente.nombreCliente,
                correo:nuevoCliente.correo
            }})
            .then((data)=>{res.json(data)})
            .catch((error)=>res.send(error));
    }
    else{
        console.log('Con password',nuevoCliente.password);


        Cliente.updateOne({nombreCliente:nombreCliente},
            {$set: {
                nombreCliente:nuevoCliente.nombreCliente,
                password:nuevoCliente.password,
                correo:nuevoCliente.correo
            }})
        .then((data)=>{res.json(data)})
        .catch((error)=>res.send(error));
    }

   
})

router.delete("/cliente/:nombreCliente",(req,res)=>{
    const { nombreCliente }=req.params;

    Cliente.deleteOne({nombreCliente:nombreCliente})
    .then((data)=>res.json(data))
    .catch((error)=>res.send(error));
})

module.exports = router;