const express = require ("express");
const mongoose = require("mongoose");
const usuarioRoutes = require("./routers/usuario");
const clienteRoutes = require("./routers/clientes");
const productoRouters = require("./routers/producto");
const carritoRouters = require("./routers/carrito");
const marcaRouters = require("./routers/marca");

//settings
const app = express();
const port = 4040; // ************** CADENA DE CONEXION ***************************************** NOMBRE DE LA BASE DE DATOS
//const mongo_Uri = "mongodb+srv://Wilmer:Pelon1234@atlascluster.2hnnkzy.mongodb.net/DB_VENTA?retryWrites=true&w=majority"
const MONGO_URI =  "mongodb+srv://victorgaitan838:%40d28AKATSUKI1228@cluster0.aym34yb.mongodb.net/DB_Venta"

//Routes
//midleware
app.use(express.json());
app.use("/api",usuarioRoutes);
app.use("/api",clienteRoutes);
app.use("/api",productoRouters);
app.use("/api",carritoRouters);
app.use("/api",marcaRouters);

app.get("/",(req,res) => { 
    res.send("<h1>Aplicacion de ventas</h1>")
})

//mongodb connections
mongoose
    .connect(MONGO_URI)
    .then(()=> console.log("Conectado a MongoDB"))
    .catch((error)=>console.error(error));


app.listen(port,() =>{
    console.log("Aplicacion corriendo en puerto",port);
})
