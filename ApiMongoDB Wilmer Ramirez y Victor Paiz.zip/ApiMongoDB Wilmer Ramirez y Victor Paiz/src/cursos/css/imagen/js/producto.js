let productoSeleccionado;

let nombreProductoEdit = document.getElementById('nombreProductoEdit');
let DescripcionEdit = document.getElementById('DescripcionEdit');
let PrecioEdit = document.getElementById('PrecioEdit');

const modalEditar = new bootstrap.Modal('#modalEditarProducto');

let tblProducto = $('#tblProducto').DataTable({
    ajax: {
        url : API_BASE_URL + '/producto',
        dataSrc: ''
    },
    columns:[
        {
            data: 'nombreProducto'
        },
        {
            data: 'descripcionProducto'
        },
        {
            data: 'precio'
        }
    ],
    Select: {
        style: 'single'
    }
})

function askDelete(){
    
    if(tblProducto.rows({select: true }).count()== 0){
        alert("Seleccione El Producto Que desea eliminar");
    }else{
        productoSeleccionado = tblProducto.rows({ selected: true}).data();

        if(confirm(`¿Desea eliminar el producto ${productoSeleccionado.nombreProducto}?`)){
            EliminarProducto();
        }
    }
}

async function EliminarProducto() {

const response = await fetch( API_BASE_URL + '/producto/' + productoSeleccionado.nombreProducto,{
    method: 'DELETE'
});


if (response.status == 200){
    alert('Producto eliminado');
    tblProducto.ajax.reload();
}else {
    alert('Error al Procesar La Solicitud');
}

}

function mostrarModal(accion){

    if(accion=='Editar'){
        if(tblProducto.rows({ select: true }).count() == 0){
            alert("Seleccione El producto Que desea Editar");
        }else{
            productoSeleccionado = tblProducto.row({ selected: true}).data();

            DescripcionEdit.value='';

            nombreProductoEdit.value=productoSeleccionado.nombreProducto;
            PrecioEdit.value=ProductoSeleccionado.precio;

            modalEditar.show();
        }
    }
}

async function ActualizarProducto(){
    let nombreProducto = nombreProductoEdit.value;
    let Descripcion = DescripcionEdit.value;
    let precio = PrecioEdit.value;


    let data = {
        nombreProducto: nombreProducto,
        Descripcion: Descripcion,
        precio: precio
    }

    if(Descripcion!=''){
        data.Descripcion=Descripcion;
    }

    const response = await fetch(API_BASE_URL + '/producto/' + nombreProducto,{
        method: 'PUT',
        headers: {
            'Content-Type' : 'application/json'
        },
        body: JSON.stringify(data)
    });

    if(response.status == 200){
        alert('Producto Actualizado');
        tblProducto.ajax.reload();
    }else 
    {
        alert('Error Al Procesar la solicitud');
    }
}

async function GuardarProducto(){

    let nombreProducto = document.getElementById('nombreProducto').value;
    let Descripcion = document.getElementById('Descripcion').value;
    let precio = document.getElementById('precio').value;

    let data = {
        nombreProducto: nombreProducto,
        Descripcion: Descripcion,
        precio: precio
    }

    const response = await fetch(API_BASE_URL + '/producto',{
        method: 'POST',
        headers: {
            'Content-type' : 'application/json'
        },
        body: JSON.stringify(data)
    });

    if(response.status == 200){
        alert('Producto Creado');
        tblProducto.ajax.reload();
    }else{
        alert('Error al Procesar la Solicitud');
    }
}