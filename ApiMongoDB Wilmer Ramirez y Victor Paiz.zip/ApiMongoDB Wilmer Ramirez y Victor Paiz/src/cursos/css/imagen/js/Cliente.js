let clienteSeleccionado;

let nombreClienteEdit = document.getElementById('nombreClienteEdit');
let passwordEdit = document.getElementById('passwordEdit');
let correoEdit = document.getElementById('correoEdit');

const modalEditar = new bootstrap.Modal('#modalEditarCliente');

let tblCliente = $('#tblCliente').DataTable({
    ajax: {
        url : API_BASE_URL + '/cliente',
        dataSrc: ''
    },
    columns:[
        {
            data: 'nombreCliente'
        },
        {
            data: 'correo'
        }
    ],
    Select: {
        style: 'single'
    }
})

function askDelete(){
    
    if(tblCliente.rows({select: true }).count()== 0){
        alert("Seleccione El Cliente Que deseaeliminar");
    }else{
        clienteSeleccionado = tblCliente.rows({ selected: true}).data();

        if(confirm(`¿Desea eliminar al cliente ${clienteSeleccionado.nombreCliente}?`)){
            EliminarCliente();
        }
    }
}

async function EliminarCliente() {

const response = await fetch( API_BASE_URL + '/cliente/' + clienteSeleccionado.nombreCliente,{
    method: 'DELETE'
});


if (response.status == 200){
    alert('Cliente eliminado');
    tblCliente.ajax.reload();
}else {
    alert('Error al Procesar La Solicitud');
}

}

function mostrarModal(accion){

    if(accion=='Editar'){
        if(tblCliente.rows({ select: true }).count() == 0){
            alert("Seleccione El Cliente Que desea Editar");
        }else{
            clienteSeleccionado = tblCliente.row({ selected: true}).data();

            passwordEdit.value='';

            nombreClienteEdit.value=clienteSeleccionado.nombreCliente;
            correoEdit.value=clienteSeleccionado.correo;

            modalEditar.show();
        }
    }
}

async function ActualizarCliente(){
    let nombreCliente = nombreClienteEdit.value;
    let password = passwordEdit.value;
    let correo = correoEdit.value;


    let data = {
        nombreCliente: nombreCliente,
        correo: correo
    }

    if(password!=''){
        data.password=password;
    }

    const response = await fetch(API_BASE_URL + '/cliente/' + nombreCliente,{
        method: 'PUT',
        headers: {
            'Content-Type' : 'application/json'
        },
        body: JSON.stringify(data)
    });

    if(response.status == 200){
        alert('Cliente Actualizado');
        tblCliente.ajax.reload();
    }else 
    {
        alert('Error Al Procesar la solicitud');
    }
}

async function GuardarCliente(){

    let nombreCliente = document.getElementById('nombreCliente').value;
    let password = document.getElementById('password').value;
    let correo = document.getElementById('correo').value;

    let data = {
        nombreCliente: nombreCliente,
        password: password,
        correo: correo
    }

    const response = await fetch(API_BASE_URL + '/cliente',{
        method: 'POST',
        headers: {
            'Content-type' : 'application/json'
        },
        body: JSON.stringify(data)
    });

    if(response.status == 200){
        alert('cliente Creado');
        tblCliente.ajax.reload();
    }else{
        alert('Error al Procesar la Solicitud');
    }
}