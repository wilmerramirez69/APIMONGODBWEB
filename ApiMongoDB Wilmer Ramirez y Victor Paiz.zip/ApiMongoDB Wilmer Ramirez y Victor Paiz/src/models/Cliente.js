const mongoose = require("mongoose");

const clienteSchema = mongoose.Schema({
    Nombre: {
        type: String,
        require: true
    },
    Apellido:{
        type: String,
        required: true
    },
    Correo:{
        type: String,
        required: true
    },
    Pasword:{
        type: String,
        required: true
    },    
    FechaRegistro:{
        type: Date,
        required: true
    }
});

module.exports=mongoose.model('Cliente', clienteSchema);