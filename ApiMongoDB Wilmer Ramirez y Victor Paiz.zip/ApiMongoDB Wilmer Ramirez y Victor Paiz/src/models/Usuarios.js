const mongoose = require("mongoose");

const usuarioSchema = mongoose.Schema({
    Nombre: {
        type: String,
        require: true
    },
    Apellido:{
        type:String,
        require: true
    },
    Pasword:{
        type: String,
        required: true
    },
    Correo:{
        type: String,
        required: true
    },
    FechaRegistro:{
        type:Date,
        require: true
    }
});

module.exports=mongoose.model('Usuario', usuarioSchema);
