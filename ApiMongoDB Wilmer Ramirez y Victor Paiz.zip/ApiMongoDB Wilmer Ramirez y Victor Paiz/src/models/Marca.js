const mongoose = require("mongoose");

const MarcaSchema = mongoose.Schema({
    NombreMarca: {
        type: String,
        require: true
    },
    Descripcion:{
        type:String,
        require: true
    },
    FechaRegistro:{
        type:Date,
        require:true
    }
})
module.exports=mongoose.model('Marca', MarcaSchema);