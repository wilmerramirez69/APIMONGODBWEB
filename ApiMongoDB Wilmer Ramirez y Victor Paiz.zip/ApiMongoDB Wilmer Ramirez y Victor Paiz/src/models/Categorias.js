const mongoose = require("mongoose");

const categoriaSchema = mongoose.Schema({
    Descripcion: {
        type: String,
        require: true
    },
    FechaRegistro:{
        type:Date,
        require:true
    }
})

module.exports = mongoose.model('Categorias', categoriaSchema);