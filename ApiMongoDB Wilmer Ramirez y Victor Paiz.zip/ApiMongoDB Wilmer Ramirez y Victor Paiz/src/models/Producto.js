const { Decimal128 } = require("mongodb");
const mongoose = require("mongoose");

const productoSchema = mongoose.Schema({
    NombreProducto: {
        type: String,
        require: true
    },
    Descripcion:{
        type: String,
        required: true
    },
    Precio:{
        type: Decimal128,
        required: true
    },    
    FechaRegistro:{
        type: Date,
        required: true
    }
});

module.exports=mongoose.model('Producto', productoSchema);