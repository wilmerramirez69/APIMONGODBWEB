const mongoose = require("mongoose");

const carritoSchema = mongoose.Schema({
    Descripcion:{
        type: String,
        require: true
    },
    Fecharegistro: {
        type: Date,
        require: true
    }
})

module.exports = mongoose.model('Carrito', carritoSchema);