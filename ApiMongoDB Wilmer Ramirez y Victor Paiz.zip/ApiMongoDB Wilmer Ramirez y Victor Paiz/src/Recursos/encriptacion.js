const bcrypt = require("bcryptjs");

//Encriptacion de contrasena
async function encryptar (pasword){
    let paswordHash = await bcrypt.hash(pasword,8);

    return paswordHash;
}
//Validacion de contrasena ingresada con la que se encuentra guardada e incripada en sistema
async function CompararPassword (pasword, paswordHash)
{
    var ValPasword = await bcrypt.compare(pasword,paswordHash);
    return ValPasword;

}

module.exports.encryptar = encryptar;
module.exports.CompararPassword = CompararPassword;
